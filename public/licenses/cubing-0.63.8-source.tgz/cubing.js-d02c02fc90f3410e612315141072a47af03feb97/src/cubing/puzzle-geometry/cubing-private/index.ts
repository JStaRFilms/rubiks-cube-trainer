export { legacyPuzzleNameMapping } from "../pgPuzzles";
